/* This is a generated file, don't edit */

#define NUM_APPLETS 215

const char applet_names[] ALIGN1 = ""
"[" "\0"
"[[" "\0"
"addgroup" "\0"
"adduser" "\0"
"adjtimex" "\0"
"arp" "\0"
"arping" "\0"
"ash" "\0"
"awk" "\0"
"base64" "\0"
"basename" "\0"
"blockdev" "\0"
"bootchartd" "\0"
"bunzip2" "\0"
"bzcat" "\0"
"cal" "\0"
"cat" "\0"
"catv" "\0"
"chgrp" "\0"
"chmod" "\0"
"chown" "\0"
"chroot" "\0"
"chvt" "\0"
"cksum" "\0"
"clear" "\0"
"cmp" "\0"
"cp" "\0"
"cut" "\0"
"date" "\0"
"dc" "\0"
"dd" "\0"
"deallocvt" "\0"
"delgroup" "\0"
"deluser" "\0"
"df" "\0"
"dhcprelay" "\0"
"diff" "\0"
"dirname" "\0"
"dmesg" "\0"
"dnsdomainname" "\0"
"dos2unix" "\0"
"du" "\0"
"dumpkmap" "\0"
"dumpleases" "\0"
"echo" "\0"
"egrep" "\0"
"env" "\0"
"expr" "\0"
"false" "\0"
"fbset" "\0"
"fdisk" "\0"
"fgconsole" "\0"
"fgrep" "\0"
"find" "\0"
"flock" "\0"
"free" "\0"
"fsck.minix" "\0"
"ftpd" "\0"
"ftpget" "\0"
"ftpput" "\0"
"getopt" "\0"
"getty" "\0"
"grep" "\0"
"groups" "\0"
"gunzip" "\0"
"gzip" "\0"
"halt" "\0"
"head" "\0"
"hexdump" "\0"
"hostid" "\0"
"hostname" "\0"
"httpd" "\0"
"hwclock" "\0"
"id" "\0"
"ifconfig" "\0"
"inetd" "\0"
"init" "\0"
"insmod" "\0"
"install" "\0"
"iostat" "\0"
"kill" "\0"
"killall" "\0"
"klogd" "\0"
"less" "\0"
"ln" "\0"
"loadfont" "\0"
"loadkmap" "\0"
"logger" "\0"
"login" "\0"
"logname" "\0"
"logread" "\0"
"losetup" "\0"
"ls" "\0"
"lsmod" "\0"
"lsof" "\0"
"lspci" "\0"
"lsusb" "\0"
"md5sum" "\0"
"mesg" "\0"
"mkdir" "\0"
"mke2fs" "\0"
"mkfifo" "\0"
"mkfs.ext2" "\0"
"mkfs.minix" "\0"
"mknod" "\0"
"mkswap" "\0"
"mktemp" "\0"
"modinfo" "\0"
"modprobe" "\0"
"more" "\0"
"mount" "\0"
"mpstat" "\0"
"mv" "\0"
"nbd-client" "\0"
"nc" "\0"
"netstat" "\0"
"nice" "\0"
"nslookup" "\0"
"ntpd" "\0"
"od" "\0"
"openvt" "\0"
"passwd" "\0"
"patch" "\0"
"pgrep" "\0"
"pidof" "\0"
"ping" "\0"
"ping6" "\0"
"pivot_root" "\0"
"pkill" "\0"
"pmap" "\0"
"poweroff" "\0"
"powertop" "\0"
"printf" "\0"
"ps" "\0"
"pstree" "\0"
"pwd" "\0"
"pwdx" "\0"
"rdate" "\0"
"readlink" "\0"
"realpath" "\0"
"reboot" "\0"
"renice" "\0"
"reset" "\0"
"resize" "\0"
"rev" "\0"
"rm" "\0"
"rmdir" "\0"
"rmmod" "\0"
"route" "\0"
"run-parts" "\0"
"rx" "\0"
"sed" "\0"
"seq" "\0"
"setlogcons" "\0"
"setserial" "\0"
"sh" "\0"
"sha1sum" "\0"
"sleep" "\0"
"smemcap" "\0"
"sort" "\0"
"stty" "\0"
"su" "\0"
"swapoff" "\0"
"swapon" "\0"
"sync" "\0"
"sysctl" "\0"
"syslogd" "\0"
"tail" "\0"
"tar" "\0"
"taskset" "\0"
"tee" "\0"
"telnet" "\0"
"telnetd" "\0"
"test" "\0"
"tftp" "\0"
"time" "\0"
"top" "\0"
"touch" "\0"
"tr" "\0"
"traceroute" "\0"
"traceroute6" "\0"
"true" "\0"
"tty" "\0"
"ubiattach" "\0"
"ubidetach" "\0"
"ubimkvol" "\0"
"ubirmvol" "\0"
"ubirsvol" "\0"
"ubiupdatevol" "\0"
"udhcpc" "\0"
"udhcpd" "\0"
"umount" "\0"
"uname" "\0"
"uniq" "\0"
"unix2dos" "\0"
"unxz" "\0"
"unzip" "\0"
"uptime" "\0"
"users" "\0"
"usleep" "\0"
"vi" "\0"
"vlock" "\0"
"wall" "\0"
"watchdog" "\0"
"wc" "\0"
"wget" "\0"
"which" "\0"
"who" "\0"
"whoami" "\0"
"whois" "\0"
"xargs" "\0"
"xz" "\0"
"xzcat" "\0"
"yes" "\0"
"zcat" "\0"
;

#ifndef SKIP_applet_main
int (*const applet_main[])(int argc, char **argv) = {
test_main,
test_main,
addgroup_main,
adduser_main,
adjtimex_main,
arp_main,
arping_main,
ash_main,
awk_main,
base64_main,
basename_main,
blockdev_main,
bootchartd_main,
bunzip2_main,
bunzip2_main,
cal_main,
cat_main,
catv_main,
chgrp_main,
chmod_main,
chown_main,
chroot_main,
chvt_main,
cksum_main,
clear_main,
cmp_main,
cp_main,
cut_main,
date_main,
dc_main,
dd_main,
deallocvt_main,
deluser_main,
deluser_main,
df_main,
dhcprelay_main,
diff_main,
dirname_main,
dmesg_main,
hostname_main,
dos2unix_main,
du_main,
dumpkmap_main,
dumpleases_main,
echo_main,
grep_main,
env_main,
expr_main,
false_main,
fbset_main,
fdisk_main,
fgconsole_main,
grep_main,
find_main,
flock_main,
free_main,
fsck_minix_main,
ftpd_main,
ftpgetput_main,
ftpgetput_main,
getopt_main,
getty_main,
grep_main,
id_main,
gunzip_main,
gzip_main,
halt_main,
head_main,
hexdump_main,
hostid_main,
hostname_main,
httpd_main,
hwclock_main,
id_main,
ifconfig_main,
inetd_main,
init_main,
insmod_main,
install_main,
iostat_main,
kill_main,
kill_main,
klogd_main,
less_main,
ln_main,
loadfont_main,
loadkmap_main,
logger_main,
login_main,
logname_main,
logread_main,
losetup_main,
ls_main,
lsmod_main,
lsof_main,
lspci_main,
lsusb_main,
md5_sha1_sum_main,
mesg_main,
mkdir_main,
mkfs_ext2_main,
mkfifo_main,
mkfs_ext2_main,
mkfs_minix_main,
mknod_main,
mkswap_main,
mktemp_main,
modinfo_main,
modprobe_main,
more_main,
mount_main,
mpstat_main,
mv_main,
nbdclient_main,
nc_main,
netstat_main,
nice_main,
nslookup_main,
ntpd_main,
od_main,
openvt_main,
passwd_main,
patch_main,
pgrep_main,
pidof_main,
ping_main,
ping6_main,
pivot_root_main,
pgrep_main,
pmap_main,
halt_main,
powertop_main,
printf_main,
ps_main,
pstree_main,
pwd_main,
pwdx_main,
rdate_main,
readlink_main,
realpath_main,
halt_main,
renice_main,
reset_main,
resize_main,
rev_main,
rm_main,
rmdir_main,
rmmod_main,
route_main,
run_parts_main,
rx_main,
sed_main,
seq_main,
setlogcons_main,
setserial_main,
ash_main,
md5_sha1_sum_main,
sleep_main,
smemcap_main,
sort_main,
stty_main,
su_main,
swap_on_off_main,
swap_on_off_main,
sync_main,
sysctl_main,
syslogd_main,
tail_main,
tar_main,
taskset_main,
tee_main,
telnet_main,
telnetd_main,
test_main,
tftp_main,
time_main,
top_main,
touch_main,
tr_main,
traceroute_main,
traceroute6_main,
true_main,
tty_main,
ubi_tools_main,
ubi_tools_main,
ubi_tools_main,
ubi_tools_main,
ubi_tools_main,
ubi_tools_main,
udhcpc_main,
udhcpd_main,
umount_main,
uname_main,
uniq_main,
dos2unix_main,
unxz_main,
unzip_main,
uptime_main,
who_main,
usleep_main,
vi_main,
vlock_main,
wall_main,
watchdog_main,
wc_main,
wget_main,
which_main,
who_main,
whoami_main,
whois_main,
xargs_main,
unxz_main,
unxz_main,
yes_main,
gunzip_main,
};
#endif

const uint16_t applet_nameofs[] ALIGN2 = {
0x0000,
0x0002,
0x0005,
0x000e,
0x0016,
0x001f,
0x0023,
0x002a,
0x002e,
0x0032,
0x0039,
0x0042,
0x004b,
0x0056,
0x005e,
0x0064,
0x0068,
0x006c,
0x0071,
0x0077,
0x007d,
0x0083,
0x008a,
0x008f,
0x0095,
0x009b,
0x009f,
0x00a2,
0x00a6,
0x00ab,
0x00ae,
0x00b1,
0x00bb,
0x00c4,
0x00cc,
0x00cf,
0x00d9,
0x00de,
0x00e6,
0x00ec,
0x00fa,
0x0103,
0x0106,
0x010f,
0x011a,
0x011f,
0x0125,
0x0129,
0x012e,
0x0134,
0x013a,
0x0140,
0x014a,
0x0150,
0x0155,
0x015b,
0x0160,
0x016b,
0x0170,
0x0177,
0x017e,
0x0185,
0x018b,
0x0190,
0x0197,
0x019e,
0x01a3,
0x01a8,
0x01ad,
0x01b5,
0x01bc,
0x01c5,
0x01cb,
0x01d3,
0x01d6,
0x01df,
0x01e5,
0x01ea,
0x01f1,
0x01f9,
0x0200,
0x0205,
0x020d,
0x0213,
0x0218,
0x021b,
0x0224,
0x022d,
0x8234,
0x023a,
0x0242,
0x024a,
0x0252,
0x0255,
0x025b,
0x0260,
0x0266,
0x026c,
0x0273,
0x0278,
0x027e,
0x0285,
0x028c,
0x0296,
0x02a1,
0x02a7,
0x02ae,
0x02b5,
0x02bd,
0x02c6,
0x02cb,
0x02d1,
0x02d8,
0x02db,
0x02e6,
0x02e9,
0x02f1,
0x02f6,
0x02ff,
0x0304,
0x0307,
0x830e,
0x0315,
0x031b,
0x0321,
0x4327,
0x432c,
0x0332,
0x033d,
0x0343,
0x0348,
0x0351,
0x035a,
0x0361,
0x0364,
0x036b,
0x036f,
0x0374,
0x037a,
0x0383,
0x038c,
0x0393,
0x039a,
0x03a0,
0x03a7,
0x03ab,
0x03ae,
0x03b4,
0x03ba,
0x03c0,
0x03ca,
0x03cd,
0x03d1,
0x03d5,
0x03e0,
0x03ea,
0x03ed,
0x03f5,
0x03fb,
0x0403,
0x0408,
0x840d,
0x0410,
0x0418,
0x041f,
0x0424,
0x042b,
0x0433,
0x0438,
0x043c,
0x0444,
0x0448,
0x044f,
0x0457,
0x045c,
0x0461,
0x0466,
0x046a,
0x0470,
0x4473,
0x447e,
0x048a,
0x048f,
0x0493,
0x049d,
0x04a7,
0x04b0,
0x04b9,
0x04c2,
0x04cf,
0x04d6,
0x04dd,
0x04e4,
0x04ea,
0x04ef,
0x04f8,
0x04fd,
0x0503,
0x050a,
0x0510,
0x0517,
0x851a,
0x8520,
0x0525,
0x052e,
0x0531,
0x0536,
0x053c,
0x0540,
0x0547,
0x054d,
0x0553,
0x0556,
0x055c,
0x0560,
};

const uint8_t applet_install_loc[] ALIGN1 = {
0x11,
0x11,
0x22,
0x11,
0x11,
0x21,
0x12,
0x11,
0x11,
0x11,
0x21,
0x11,
0x11,
0x11,
0x11,
0x11,
0x11,
0x21,
0x11,
0x11,
0x11,
0x11,
0x11,
0x11,
0x21,
0x12,
0x11,
0x11,
0x22,
0x11,
0x21,
0x11,
0x11,
0x12,
0x11,
0x21,
0x12,
0x22,
0x22,
0x11,
0x11,
0x12,
0x21,
0x12,
0x11,
0x22,
0x21,
0x11,
0x11,
0x11,
0x12,
0x22,
0x21,
0x21,
0x12,
0x11,
0x21,
0x11,
0x11,
0x12,
0x11,
0x11,
0x11,
0x21,
0x11,
0x12,
0x11,
0x11,
0x21,
0x11,
0x12,
0x11,
0x11,
0x21,
0x12,
0x11,
0x21,
0x11,
0x11,
0x11,
0x11,
0x22,
0x21,
0x12,
0x11,
0x11,
0x12,
0x11,
0x11,
0x11,
0x11,
0x21,
0x22,
0x22,
0x22,
0x12,
0x11,
0x11,
0x11,
0x11,
0x11,
0x21,
0x11,
0x11,
0x11,
0x11,
0x11,
0x01,
};

#define MAX_APPLET_NAME_LEN 13
